#! /usr/bin/env bash

set -o pipefail
set -o nounset
set -o errexit

S_Time="`date +'%s'`"
install=1
index=0
Mongo_Conf='/etc/mongod.conf'
Repo_Name='/etc/yum.repos.d/mongodb.repo'
packages=(mongodb-org-7.0.14 mongodb-org-database-7.0.14 mongodb-org-server-7.0.14 mongodb-mongosh mongodb-org-mongos-7.0.14 mongodb-org-tools-7.0.14)
service='/usr/lib/systemd/system/mongod.service'

trap 'onCtrlC' INT
function onCtrlC () {
        #捕获CTRL+C，当脚本被ctrl+c的形式终止时同时终止程序的后台进程
        echo
        printf "\e[45;5m %s \e[39;0m\n" '已检测Ctrl+C手动停止!!'
        exit 17
}

function print_msg(){
:<<EOF

  iii     nnn        ssss      tt         aaaa       ll       ll                mm   mm        oo       nnn        gggggg     oo            dd    bb                  ssss    hh
        nn   nn    ss    ss    tt       aa    aa     ll       ll              m    mm   m    oo  oo   nn   nn    gg    gg   oo  oo          dd    bb                ss    ss  hh
  iii   nn   nn   ss      s  tttttt    aa      aa    ll       ll             mm    mm   mm  oo    oo  nn   nn   gg     gg  oo    oo         dd    bb               ss      s  hh   
  iii   nn   nn    sss         tt      aa      aa    ll       ll             mm    mm   mm  oo    oo  nn   nn   gg   gggg  oo    oo     dddddd    bbbbbb            sss       hh  hhhh
  iii   nn   nn       sss      tt      aa      aa    ll       ll             mm    mm   mm  oo    oo  nn   nn   gg  gg gg  oo    oo   dd    dd    bb    bb             sss    hhhh   hh
  iii   nn   nn         sss    tt      aa      aa    ll       ll             mm    mm   mm  oo    oo  nn   nn    gggg  gg  oo    oo  dd     dd    bb     bb              sss  hhh    hh
  iii   nn   nn   s     sss    tt   tt aa      aa    ll    ll ll    ll       mm    mm   mm  oo    oo  nn   nn          gg  oo    oo  dd     dd    bb     bb        s     sss  hh     hh
  iii   nn   nn    ss   sss    tt  tt   aaa   aaa    ll   ll  ll   ll        mm    mm   mm   oo  oo   nn   nn    gg   gg    oo  oo   dd     ddd   bb     bb         ss   sss  hh     hh
  iii   nn   nn      ssss       ttt       aaaa   aa   lll      lll    ====== mm    mm   mm     oo     nn   nn       gg        oo      dddddddd d  bbbbbbb     (())    ssss    hh     hh
 
EOF
echo ''
    # line 1
    printf "\e[33;3;1m\e[2G%s\e[10G%s\e[21G%s\e[31G%s\e[43G%s\e[54G%s\e[63G%s\e[81G%s\e[86G%s\e[96G%s\e[105G%s\e[116G%s\e[127G%s\e[141G%s\e[147G%s\e[167G%s\e[175G%s\e[39;0m\n" \
    'iii' 'nnn' 'ssss' 'tt' 'aaaa' 'll' 'll' 'mm' 'mm' 'oo' 'nnn' 'gggggg' 'oo' 'dd' 'bb' 'ssss' 'hh'
    # line 2
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[19G%s\e[25G%s\e[31G%s\e[41G%s\e[47G%s\e[54G%s\e[63G%s\e[79G%s\e[84G%s\e[89G%s\e[94G%s\e[98G%s\e[103G%s\e[108G%s\e[114G%s \
            \e[120G%s\e[125G%s\e[129G%s\e[141G%s\e[147G%s\e[165G%s\e[171G%s\e[175G%s\e[39;0m\n" \
    '' 'nn' 'nn' 'ss' 'ss' 'tt' 'aa' 'aa' 'll' 'll' 'm' 'mm' 'm' 'oo' 'oo' 'nn' 'nn' 'gg' 'gg' 'oo' 'oo' 'dd' 'bb' 'ss' 'ss' 'hh' 
    # line 3
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[18G%s\e[26G%s\e[29G%s\e[40G%s\e[48G%s\e[54G%s\e[63G%s\e[78G%s\e[84G%s\e[89G%s\e[93G%s\e[99G%s\e[103G%s\e[108G%s\e[113G%s \
            \e[120G%s\e[124G%s\e[130G%s\e[141G%s\e[147G%s\e[164G%s\e[172G%s\e[175G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 'ss' 's' 'tttttt' 'aa' 'aa' 'll' 'll' 'mm' 'mm' 'mm' 'oo' 'oo' 'nn' 'nn' 'gg' 'gg' 'oo' 'oo' 'dd' 'bb' 'ss' 's' 'hh' 
    # line 4
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[19G%s\e[31G%s\e[40G%s\e[48G%s\e[54G%s\e[63G%s\e[78G%s\e[84G%s\e[89G%s\e[93G%s\e[99G%s\e[103G%s\e[108G%s\e[112G%s\e[118G%s \
            \e[124G%s\e[130G%s\e[137G%s\e[147G%s\e[165G%s\e[175G%s\e[179G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 'sss' 'tt' 'aa' 'aa' 'll' 'll' 'mm' 'mm' 'mm' 'oo' 'oo' 'nn' 'nn' 'gg' 'gggg' 'oo' 'oo' 'dddddd' 'bbbbbb' 'sss' 'hh' 'hhhh'
    # line 5
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[22G%s\e[31G%s\e[40G%s\e[48G%s\e[54G%s\e[63G%s\e[78G%s\e[84G%s\e[89G%s\e[93G%s\e[99G%s\e[103G%s\e[108G%s\e[112G%s\e[117G%s \
            \e[124G%s\e[130G%s\e[135G%s\e[141G%s\e[147G%s\e[152G%s\e[168G%s\e[175G%s\e[182G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 'sss' 'tt' 'aa' 'aa' 'll' 'll' 'mm' 'mm' 'mm' 'oo' 'oo' 'nn' 'nn' 'gg' 'gg gg' 'oo' 'oo' 'dd' 'dd' 'bb' 'bb' 'sss' 'hhhh' 'hh'
    # line 6
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[24G%s\e[31G%s\e[40G%s\e[48G%s\e[54G%s\e[63G%s\e[78G%s\e[84G%s\e[89G%s\e[93G%s\e[99G%s\e[103G%s\e[108G%s\e[113G%s\e[120G%s \
            \e[124G%s\e[130G%s\e[134G%s\e[141G%s\e[147G%s\e[153G%s\\e[170G%s\e[175G%s\e[182G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 'sss' 'tt' 'aa' 'aa'  'll' 'll' 'mm' 'mm' 'mm' 'oo' 'oo' 'nn' 'nn' 'gggg' 'gg'  'oo' 'oo' 'dd' 'dd' 'bb' 'bb' 'sss' 'hhh' 'hh'
    # line 7
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[18G%s\e[24G%s\e[31G%s\e[36G%s\e[40G%s\e[48G%s\e[54G%s\e[60G%s\e[63G%s\e[68G%s\e[78G%s\e[84G%s\e[89G%s\e[93G%s\e[99G%s\e[103G%s \
            \e[108G%s\e[120G%s\e[124G%s\e[130G%s\e[134G%s\e[141G%s\e[147G%s\e[153G%s\e[164G%s\e[170G%s\e[175G%s\e[182G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 's' 'sss' 'tt' 'tt' 'aa' 'aa' 'll' 'll' 'll' 'll' 'mm' 'mm' 'mm' 'oo' 'oo' 'nn' 'nn' 'gg' 'oo' 'oo' 'dd' 'dd' 'bb' 'bb' 's' 'sss' 'hh' 'hh'
    # line 8
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[19G%s\e[24G%s\e[31G%s\e[35G%s\e[41G%s\e[47G%s\e[54G%s\e[59G%s\e[63G%s\e[67G%s\e[78G%s\e[84G%s\e[89G%s\e[94G%s\e[98G%s\e[103G%s \
            \e[108G%s\e[114G%s\e[119G%s\e[125G%s\e[129G%s\e[134G%s\e[141G%s\e[147G%s\e[153G%s\e[165G%s\e[170G%s\e[175G%s\e[182G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 'ss' 'sss' 'tt' 'tt' 'aaa' 'aaa' 'll' 'll' 'll' 'll' 'mm' 'mm' 'mm' 'oo' 'oo' 'nn' 'nn' 'gg' 'gg' 'oo' 'oo' 'dd' 'ddd' 'bb' 'bb' 'ss' 'sss' 'hh' 'hh'
    # line 9
    printf "\e[33;3;1m\e[2G%s\e[8G%s\e[13G%s\e[21G%s\e[32G%s\e[44G%s\e[50G%s\e[55G%s\e[64G%s\e[70G%s\e[78G%s\e[84G%s\e[89G%s\e[96G%s\e[103G%s\e[108G%s\e[117G%s\e[127G%s\e[135G%s \
            \e[144G%s\e[147G%s\e[158G%s\e[167G%s\e[175G%s\e[182G%s\e[39;0m\n" \
    'iii' 'nn' 'nn' 'ssss' 'ttt' 'aaaa' 'aa' 'lll' 'lll' '======' 'mm' 'mm' 'mm' 'oo' 'nn' 'nn' 'gg' 'oo' 'dddddddd' 'd' 'bbbbbbb' '(())' 'ssss' 'hh' 'hh'
    echo

}

function end_time(){
    E_Time="$(date +'%s')"
    Total_Time="$((${E_Time}-${S_Time}))"
    printf "\e[35;1m%s\e[39;0m\n" "安装脚本总用时\"${Total_Time}\"秒"
}

print_msg
#检查是否cpu是否flag是否支持'avx'
support='
    test -z "$(grep -iw 'avx'< <(lscpu))"  && \
    printf "\e[31;1m%s\e[39;0m\n" '系统不支持安装7.0版本,请重新选择系统,系统CPU需要支持avx才能安装' && end_time && exit 7 || \
    if [  "$(rpm -qa mongo* | xargs -L 1000 | wc -w)" -ge 8 ];then
        echo "已经安装mongo"
        if [ "`systemctl is-active mongod`" == 'active' ] && (grep -v grep <<< "$(ps -aux | grep -wq mongod)");then
            echo '检查到mongodb启动成功'
            end_time
            exit 0
        else
            echo "检查到mongodb未成功启动，请检查配置"
            end_time
            exit 1
        fi
    else
        { install=0; }
        printf "正在安装mongo.....\n"
    fi 
'
eval "$support"
if [ "$install" -eq 0 ];then
    echo -n "yum仓库检测中....."
    if [ -e "$Repo_Name" ] && [ -s "$Repo_Name" ];then
        if ( grep -wq '7\.0' "$Repo_Name" );then
            echo -e "\r\e[70G\e[32;1m[OK]\e[39;0m"
        fi
    else
        if [ ! -s "/etc/yum.repos.d/lan.repo" ];then
           tee $Repo_Name< <(echo -e "[mongodb-org-7.0]\nname=MongoDB Repository\nbaseurl=https://repo.mongodb.org/yum/redhat/7/mongodb-org/7.0/x86_64/\ngpgcheck=1\nenabled=1\ngpgkey=https://pgp.mongodb.com/server-7.0.asc")
        fi
        printf '%s'"\r\e[70G\e[32;1m%s\e[39;0m\n" 'yum配置文件添加完成!!' '[OK]'
    fi
fi
echo -n "yum缓存检测中....."
if [ -z "`ls /var/cache/yum/ | xargs`"  ];then
     if (yum makecache 2> /dev/null >&2 );then
         echo -e "\r\e[70G\e[32;1m[OK]\e[39;0m"
     else
         echo -e "\r\e[70G\e[31;1m[ERROR]\e[39;0m"
     fi
else
     echo -e "\r\e[70G\e[33;1m[SKIP]\e[39;0m"
fi
until [ "$index" -ge "${#packages[*]}" ];do
    echo -n "安装\"${packages[$index]}\"中......."
    if (yum install ${packages[$index]} -y >& /dev/null);then
        echo -e "\r\e[70G\e[32;1m[OK]\e[39;0m"
    fi
    let index+=1
done

#将连接限制从仅主机改为不限制
if [ "$?" -eq 0 ];then
    if ! (sed -n '/127\.0\.0\.1/p' $Mongo_Conf | grep -q "^#");then
        sed -i '/bindIp\: 127\.0\.0\.1/ s=\(.*\)=#\1=g' $Mongo_Conf
    fi
    if [ "$(cat /etc/mongod.conf | egrep -c '[ ]+bindIp: 0.0.0.0$')" -ne 1 ];then
        sed -i '/bindIp/a bindIp: 0.0.0.0' $Mongo_Conf
        sed -i '/^bindIp/  s&\(.*\)&  bindIp: 0.0.0.0&g' $Mongo_Conf
        systemctl enable --now mongod
    fi
    printf '%s'"\r\e[70G\e[32;1m%s\e[39;0m\n" '正在安装mongo.....' '[OK]'
fi

echo -n '启动中.......'
if ! (systemctl is-active --quiet mongod);then
     sed -i '/User/ {N;d}' $service
     systemctl daemon-reload && systemctl stop mongod &&systemctl start mongod
     if [ ! -z "$(ls /var/lib/mongo | xargs)" ];then
        chown mongod:mongod /var/lib/mongo -R
        sed -i '/\[Service\]/a User=mongod' $service
        sed -i '/User/a Group=mongod' $service
        if [ -S "`ls /tmp/mongodb-[[:alnum:]]*.sock`" ];then
           chown mongod:mongod /tmp/mongodb-[:alnum:].sock
        fi
        systemctl daemon-reload && systemctl stop mongod &&systemctl start mongod
     fi
fi
if [ "$(systemctl is-active mongod)" == "active" ];then    
    echo -e "\r\e[70G\e[32;1m[OK]\e[39;0m"
    end_time
else
    echo -e "\r\e[70G\e[31;1m[ERROR]\e[39;0m"
    end_time
fi
