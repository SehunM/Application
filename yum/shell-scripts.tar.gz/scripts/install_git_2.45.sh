# !/bin/bash

set -e
set -o errexit
set -o pipefail
declare -a packages

S_DATE=$(date +'%s')
SOURCE_PATH="$PWD/git_source"
mkdir -p /usr/local/git  && mkdir "${SOURCE_PATH}" -p
cat > "${SOURCE_PATH}/i" << EOF
yes
manual
yes

EOF

test -e "${SOURCE_PATH}/git-2.45.1.tar.gz"  || \
#if (wget -S http://www.yumlocal.com:66/index.html --spider 2>/dev/null);then
#测试wget命令是否安装
if (which wget &>/dev/null 2>&1);then
    wget -P "${SOURCE_PATH}" https://mirrors.edge.kernel.org/pub/software/scm/git/git-2.45.1.tar.gz 
else
    yum -y install wget 
    wget -P "${SOURCE_PATH}" https://mirrors.edge.kernel.org/pub/software/scm/git/git-2.45.1.tar.gz 
fi

#1.安装git依赖包
packages=( \
      dh-autoreconf libcurl4-gnutls-dev libexpat1-dev gettext \
      asciidoc xmlto libz-dev libssl-dev  zlib-devel docbook2X  cpan\
      libcurl-devel curl-devel bc \
)
for i in "${packages[@]}";do
    if ( rpm -aq | grep -wq "$i");then
       echo "$i已经安装" && continue
    else
       yum install "$i" -y && continue
    fi
done

while true;do
    cpan install --force ExtUtils::MakeMaker < "${SOURCE_PATH}/i" | tee "${SOURCE_PATH}/cpan.log"
    if [ "$(cat "${SOURCE_PATH}/cpan.log" | grep -cw 'ok')" -ne "0" ];then
        rm -rf "${SOURCE_PATH}/cpan.log" && rm -rf "${SOURCE_PATH}/i"        
        break
    fi
done

#if not install MakeMaker will make error out lines
#    SUBDIR perl
#/usr/bin/perl Makefile.PL PREFIX='/usr/local/git' INSTALL_BASE='' --localedir='/usr/local/git/share/locale'
#Can't locate ExtUtils/MakeMaker.pm in @INC (@INC contains: /usr/local/lib64/perl5 /usr/local/share/perl5 /usr/lib64/perl5/vendor_perl /usr/share/perl5/vendor_perl /usr/lib64/perl5 /usr/share/perl5 .) at Makefile.PL line 3.
#BEGIN failed--compilation aborted at Makefile.PL line 3.
#make[1]: *** [perl.mak] Error 2
#make: *** [perl/perl.mak] Error 2

ln -s /usr/bin/db2x_docbook2texi /usr/bin/docbook2x-texi -f
test ! -e "${SOURCE_PATH}/git-2.45.1.tar.gz" || tar -vxzf "${SOURCE_PATH}/git-2.45.1.tar.gz" -C "${SOURCE_PATH}"
cd "${SOURCE_PATH}/git-2.45.1"
make configure
./configure --prefix=/usr/local/git/
make all doc info
make install install-doc install-html install-info
mkdir ~/git_old_version -p && mv /usr/bin/git*  ~/git_old_version  -f  
ln -s /usr/local/git/bin/* /bin/
E_DATE=$(date +'%s')
SECOND=$((${E_DATE}-${S_DATE}))
M=$(echo "sclae=2;${SECOND}/1.0/60" | bc)
echo $M | awk -v script_name=$0 '{printf script_name" 执行总用时约:%.2f分钟",$1;system("echo")}'
